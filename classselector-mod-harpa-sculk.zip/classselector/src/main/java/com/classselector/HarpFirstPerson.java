package com.classselector;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Primeira pessoa: harpa à frente do peito, levemente inclinada para a frente, cordas voltadas para o jogador,
 * mão direita na parte de baixo do braço diagonal e mão esquerda apoiando a coluna. Desenha item + braços à mão
 * (cancela a renderização padrão da mão principal). Desligável em HarpConfig.firstPersonPose.
 * Valores calibrados numa simulação; ajuste as constantes abaixo se quiser mexer na pose.
 */
@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID, value = Dist.CLIENT)
public final class HarpFirstPerson {
    // posição/orientação da harpa na tela (espaço da câmera, blocos) e escala do modelo
    private static final float RX = 0.03F, RY = -0.21F, RZ = -0.82F, YAW = 6.0F, PITCH = -10.0F, S = 0.55F;
    // pontas das mãos, em px do modelo relativos ao centro da harpa; dir = do pulso para o ombro
    private static final Vector3f TIP_R = new Vector3f(6.4F, -6.2F, -1.2F), DIR_R = new Vector3f(0.55F, -0.62F, 0.62F);
    private static final Vector3f TIP_L = new Vector3f(-6.4F, -1.0F, -1.2F), DIR_L = new Vector3f(-0.50F, -0.62F, 0.62F);

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent e) {
        if (e.getHand() != InteractionHand.MAIN_HAND || !HarpConfig.FIRST_PERSON_POSE.get()) return;
        ItemStack stack = e.getItemStack();
        if (!(stack.getItem() instanceof SculkHarpItem)) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || p.isScoping()) return;
        e.setCanceled(true);

        PoseStack ps = e.getPoseStack();
        MultiBufferSource buf = e.getMultiBufferSource();
        int light = e.getPackedLight();
        float pt = e.getPartialTick();
        boolean playing = p.isUsingItem() && p.getUseItem().getItem() instanceof SculkHarpItem;
        int using = playing ? p.getTicksUsingItem() : 0;
        float charge = playing ? SculkHarpItem.chargeFraction(using) : 0.0F;

        // balanço suave: acompanha o corpo ao andar + respiração em repouso; tremor leve durante a carga
        float time = p.tickCount + pt;
        float speed = (float) Math.min(0.3D, p.getDeltaMovement().horizontalDistance());
        float swayX = Mth.sin(time * 0.35F) * speed * 0.12F;
        float swayY = Mth.abs(Mth.cos(time * 0.35F)) * speed * 0.06F + Mth.sin(time * 0.08F) * 0.004F;
        float roll = Mth.sin(time * 0.35F) * speed * 6.0F + (playing ? Mth.sin(time * 1.7F) * charge * 0.8F : 0.0F);
        // dedilhado: a mão principal avança em direção às cordas a cada nota
        int interval = HarpConfig.PLUCK_INTERVAL.get();
        float phase = playing ? ((using % interval) + pt) / interval : 1.0F;
        float strum = playing ? Mth.sin(Mth.clamp(phase, 0.0F, 1.0F) * Mth.PI) : 0.0F;
        float swing = Mth.sin(e.getSwingProgress() * Mth.PI);

        ps.pushPose();
        ps.translate(RX + swayX, RY - e.getEquipProgress() * 0.7F + swayY - strum * 0.008F, RZ);
        ps.mulPose(Axis.YP.rotationDegrees(YAW));
        ps.mulPose(Axis.XP.rotationDegrees(PITCH - swing * 18.0F));
        ps.mulPose(Axis.ZP.rotationDegrees(roll));

        ps.pushPose();
        ps.scale(S, S, S);
        mc.getItemRenderer().renderStatic(p, stack, ItemDisplayContext.NONE, false, ps, buf, p.level(), light,
                OverlayTexture.NO_OVERLAY, p.getId());
        ps.popPose();

        if (!p.isInvisible()) {
            PlayerRenderer pr = (PlayerRenderer) mc.getEntityRenderDispatcher().getRenderer(p);
            float shoulder = "slim".equals(p.getModelName()) ? 5.5F / 16.0F : 6.0F / 16.0F;
            arm(ps, pr, buf, light, p, true, TIP_R.x - strum * 1.4F, TIP_R.y + strum * 0.8F, TIP_R.z - strum * 0.8F, DIR_R, shoulder);
            if (p.getOffhandItem().isEmpty()) arm(ps, pr, buf, light, p, false, TIP_L.x, TIP_L.y, TIP_L.z, DIR_L, shoulder);
        }
        ps.popPose();
    }

    private static void arm(PoseStack ps, PlayerRenderer pr, MultiBufferSource buf, int light, LocalPlayer p, boolean right,
                            float tx, float ty, float tz, Vector3f dir, float shoulder) {
        Vector3f d = new Vector3f(dir).normalize();
        ps.pushPose();
        ps.translate(tx / 16.0F * S, ty / 16.0F * S, tz / 16.0F * S);
        ps.mulPose(new Quaternionf().rotationTo(new Vector3f(0.0F, -1.0F, 0.0F), d));
        ps.translate(right ? shoulder : -shoulder, -12.0F / 16.0F, 0.0F);   // ponta da mão na origem
        if (right) pr.renderRightHand(ps, buf, light, p); else pr.renderLeftHand(ps, buf, light, p);
        ps.popPose();
    }

    private HarpFirstPerson() { }
}
