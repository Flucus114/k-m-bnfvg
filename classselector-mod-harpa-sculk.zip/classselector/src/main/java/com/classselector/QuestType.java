package com.classselector;

public enum QuestType {
    BOSS("Matar boss/mob"),
    ITEM("Obter item"),
    PLAYER("Matar jogador"),
    BLOCK("Minerar bloco");

    public final String label;

    QuestType(String label) { this.label = label; }

    public static QuestType of(String s) {
        try { return valueOf(s); } catch (Exception e) { return BOSS; }
    }

    public QuestType next() { return values()[(ordinal() + 1) % values().length]; }

    public boolean needsTarget() { return this != PLAYER; }
}
