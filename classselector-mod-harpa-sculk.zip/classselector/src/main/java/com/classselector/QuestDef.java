package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

public class QuestDef {
    public String id = "", tab = "", parent = "", name = "", description = "";
    public String icon = "minecraft:book";
    /** Classe que pode ver e progredir nesta quest ("" = todas). */
    public String classId = "";
    public QuestType type = QuestType.BOSS;
    public String target = "";
    public int amount = 1;
    public int xp = 0;                       // níveis de XP de recompensa
    public List<ItemStack> rewards = new ArrayList<>();

    public ItemStack iconStack() {
        ResourceLocation rl = ResourceLocation.tryParse(icon);
        Item it = rl == null ? null : ForgeRegistries.ITEMS.getValue(rl);
        return new ItemStack(it == null || it == Items.AIR ? Items.BARRIER : it);
    }

    /** Texto do objetivo, ex.: "Minerar 10x Pedra". */
    public String objective() {
        ResourceLocation rl = ResourceLocation.tryParse(target);
        String nm = target;
        switch (type) {
            case BOSS:
                if (rl != null && ForgeRegistries.ENTITY_TYPES.containsKey(rl))
                    nm = ForgeRegistries.ENTITY_TYPES.getValue(rl).getDescription().getString();
                return "Matar " + amount + "x " + nm;
            case ITEM:
                if (rl != null && ForgeRegistries.ITEMS.containsKey(rl))
                    nm = new ItemStack(ForgeRegistries.ITEMS.getValue(rl)).getHoverName().getString();
                return "Obter " + amount + "x " + nm;
            case BLOCK:
                if (rl != null && ForgeRegistries.BLOCKS.containsKey(rl)) {
                    Block b = ForgeRegistries.BLOCKS.getValue(rl);
                    nm = b.getName().getString();
                }
                return "Minerar " + amount + "x " + nm;
            default:
                return "Matar " + amount + " jogador(es)";
        }
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("id", id);
        t.putString("tab", tab);
        t.putString("parent", parent);
        t.putString("name", name);
        t.putString("description", description);
        t.putString("icon", icon);
        t.putString("classId", classId);
        t.putString("type", type.name());
        t.putString("target", target);
        t.putInt("amount", amount);
        t.putInt("xp", xp);
        ListTag l = new ListTag();
        for (ItemStack s : rewards) l.add(s.save(new CompoundTag()));
        t.put("rewards", l);
        return t;
    }

    public static QuestDef load(CompoundTag t) {
        QuestDef q = new QuestDef();
        q.id = t.getString("id");
        q.tab = t.getString("tab");
        q.parent = t.getString("parent");
        q.name = t.getString("name");
        q.description = t.getString("description");
        q.icon = t.getString("icon");
        q.classId = t.getString("classId");
        q.type = QuestType.of(t.getString("type"));
        q.target = t.getString("target");
        q.amount = Math.max(1, t.getInt("amount"));
        q.xp = Math.max(0, t.getInt("xp"));
        for (Tag x : t.getList("rewards", Tag.TAG_COMPOUND)) {
            ItemStack s = ItemStack.of((CompoundTag) x);
            if (!s.isEmpty()) q.rewards.add(s);
        }
        return q;
    }
}
