package com.classselector;

import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import org.joml.Quaternionf;

/** Partículas da harpa: nota, fragmento, faísca e anel de energia (um só tipo de classe, 4 comportamentos). */
public class HarpParticle extends TextureSheetParticle {
    public enum Kind { NOTE, SHARD, SPARK, RING }

    private final Kind kind;
    private final float baseSize;
    private final float maxRadius;

    protected HarpParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites, Kind kind) {
        super(level, x, y, z);
        this.kind = kind;
        this.pickSprite(sprites);
        this.xd = vx; this.yd = vy; this.zd = vz;
        this.hasPhysics = false;
        this.gravity = 0.0F;
        this.friction = 0.92F;
        float maxR = 1.0F;
        switch (kind) {
            case NOTE -> { this.lifetime = 30 + this.random.nextInt(16); this.baseSize = 0.22F; this.xd = 0; this.yd = 0.04D; this.zd = 0; }
            case SHARD -> { this.lifetime = 12 + this.random.nextInt(12); this.baseSize = 0.06F + this.random.nextFloat() * 0.05F; }
            case SPARK -> { this.lifetime = 8 + this.random.nextInt(8); this.baseSize = 0.14F; }
            default -> { this.lifetime = 16; this.baseSize = 0.3F; maxR = (float) Math.max(0.6D, Math.abs(vx)); this.xd = 0; this.yd = 0; this.zd = 0; }
        }
        this.maxRadius = maxR;
        this.quadSize = this.baseSize;
    }

    @Override
    public void tick() {
        this.xo = this.x; this.yo = this.y; this.zo = this.z;
        if (this.age++ >= this.lifetime) { this.remove(); return; }
        float t = this.age / (float) this.lifetime;
        switch (this.kind) {
            case NOTE -> {
                this.xd = Math.sin(this.age * 0.35D) * 0.012D;
                this.zd = Math.cos(this.age * 0.30D) * 0.012D;
                this.alpha = t > 0.7F ? 1.0F - (t - 0.7F) / 0.3F : 1.0F;
                this.move(this.xd, this.yd, this.zd);
            }
            case SHARD -> {
                this.yd -= 0.004D;
                this.quadSize = this.baseSize * (1.0F - 0.7F * t);
                this.move(this.xd, this.yd, this.zd);
                this.xd *= this.friction; this.yd *= this.friction; this.zd *= this.friction;
            }
            case SPARK -> {
                this.alpha = 1.0F - t * t;
                this.quadSize = this.baseSize * (1.0F + 0.5F * Mth.sin(t * Mth.PI));
                this.move(this.xd, this.yd, this.zd);
                this.xd *= this.friction; this.yd *= this.friction; this.zd *= this.friction;
            }
            default -> {
                float ease = 1.0F - (1.0F - t) * (1.0F - t);
                this.quadSize = this.baseSize + (this.maxRadius - this.baseSize) * ease;
                this.alpha = 1.0F - t * t;
            }
        }
    }

    @Override
    public void render(VertexConsumer buffer, Camera camera, float partialTicks) {
        if (this.kind != Kind.RING) { super.render(buffer, camera, partialTicks); return; }
        this.renderRotatedQuad(buffer, camera, new Quaternionf().rotationX(-Mth.HALF_PI), partialTicks);   // anel deitado, face p/ cima
        this.renderRotatedQuad(buffer, camera, new Quaternionf().rotationX(Mth.HALF_PI), partialTicks);    // e face p/ baixo
    }

    @Override public int getLightColor(float partialTick) { return 15728880; }   // brilho total
    @Override public ParticleRenderType getRenderType() { return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT; }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final Kind kind;
        public Provider(SpriteSet sprites, Kind kind) { this.sprites = sprites; this.kind = kind; }

        @Override
        public net.minecraft.client.particle.Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                                                     double vx, double vy, double vz) {
            return new HarpParticle(level, x, y, z, vx, vy, vz, this.sprites, this.kind);
        }
    }
}
