package com.classselector;

import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ClassSelectorMod.MODID);

    /** Sem receita, sem loot e fora das abas criativas: só via /give até você definir como obter. */
    public static final RegistryObject<Item> COSMIC_EYE = ITEMS.register("cosmic_eye", CosmicEyeItem::new);

    /** Espada do Olho Sombrio: cancela feitiços. Sem receita nem loot; só via /give por enquanto. */
    public static final RegistryObject<Item> DARK_EYE_SWORD = ITEMS.register("dark_eye_sword", DarkEyeSwordItem::new);

    /** Hyper Arco de Sculk: raio supersônico, sem flechas. Sem receita nem loot; aba criativa do mod ou /give. */
    public static final RegistryObject<Item> HYPER_SCULK_BOW = ITEMS.register("hyper_sculk_bow", HyperSculkBowItem::new);
    public static final RegistryObject<SculkHarpItem> SCULK_HARP = ITEMS.register("sculk_harp", SculkHarpItem::new);

    /** Ovo de spawn do boss Soberano Cósmico (aparece na aba de ovos de spawn). */
    public static final RegistryObject<Item> COSMIC_BOSS_EGG = ITEMS.register("cosmic_sovereign_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.COSMIC_BOSS, 0x120A24, 0x9D6BFF, new Item.Properties()));
}
