package com.classselector;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Tela de seleção de raças (visual em PickScreen). */
public class RaceSelectScreen extends PickScreen {
    public RaceSelectScreen(boolean forced) {
        super(Component.literal("Raças"), "Seleção de Raça", "Selecionar Raça", forced);
    }

    @Override
    protected List<Entry> entries() {
        List<Entry> l = new ArrayList<>();
        for (RaceDef r : ClientState.races.values()) {
            List<String> bonus = r.lines();
            if (bonus.isEmpty()) bonus = List.of("Nenhum bônus");
            l.add(new Entry(r.id, r.name, r.iconStack(), r.description, "Bônus", bonus, true, "", new ArrayList<ItemStack>()));
        }
        return l;
    }

    @Override
    protected void choose(String id) {
        Net.CH.sendToServer(new Net.SelectRace(id));
        minecraft.setScreen(null);
    }

    @Override
    protected void edit(String id) {
        RaceDef found = id == null ? null : ClientState.races.get(id);
        minecraft.setScreen(new RaceEditScreen(this, found));
    }

    @Override
    protected String emptyText() { return "Nenhuma raça criada"; }
}
