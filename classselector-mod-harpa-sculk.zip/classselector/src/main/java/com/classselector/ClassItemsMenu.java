package com.classselector;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

/**
 * Baú de 27 slots aberto para o OP: o que ele colocar aqui vira os itens da classe.
 * Usa a tela de baú do próprio Minecraft, então não precisa de GUI no cliente.
 */
public class ClassItemsMenu extends ChestMenu {
    private final String classId;
    private final SimpleContainer box;

    public static void open(ServerPlayer p, ClassDef def) {
        SimpleContainer box = new SimpleContainer(27);
        for (int i = 0; i < def.items.size() && i < 27; i++) box.setItem(i, def.items.get(i).copy());
        p.openMenu(new SimpleMenuProvider(
                (id, inv, pl) -> new ClassItemsMenu(id, inv, box, def.id),
                Component.literal("Itens da classe: " + def.name)));
    }

    private ClassItemsMenu(int id, Inventory inv, SimpleContainer box, String classId) {
        super(MenuType.GENERIC_9x3, id, inv, box, 3);
        this.box = box;
        this.classId = classId;
    }

    @Override
    public void removed(Player pl) {
        super.removed(pl);
        if (!(pl instanceof ServerPlayer sp)) return;
        ClassData data = ClassData.get(sp.server);
        ClassDef c = data.classes.get(classId);
        if (c == null) return;
        c.items.clear();
        for (int i = 0; i < box.getContainerSize(); i++) {
            ItemStack s = box.getItem(i);
            if (!s.isEmpty()) c.items.add(s.copy());
        }
        data.setDirty();
        Net.syncAll(sp.server);
    }
}
